import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  Mail,
  Phone,
  MapPin,
  Crown,
  Shield,
  Truck,
  RotateCcw,
} from "lucide-react";
import {
  SITE_CONFIG,
  SOCIAL_LINKS,
  CONTACT_INFO,
  NAVIGATION,
} from "@/lib/constants";

const Footer = () => {
  return (
    <footer className="bg-spa-900 text-spa-50">
      {/* Newsletter section */}
      <div className="bg-spa-800 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-4 font-display">
              Stay Updated with Our Latest Collections
            </h3>
            <p className="text-spa-200 mb-6">
              Be the first to know about new arrivals, exclusive offers, and
              bathroom design tips.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Enter your email address"
                className="bg-white text-gray-900 border-0"
              />
              <Button className="bg-bath-500 hover:bg-bath-600 text-white px-8">
                Subscribe
              </Button>
            </div>
            <p className="text-xs text-spa-300 mt-3">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>
      </div>

      {/* Trust badges */}
      <div className="bg-spa-800 border-t border-spa-700 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <div className="flex items-center space-x-3 text-center md:text-left">
              <Crown className="h-8 w-8 text-bath-400 mx-auto md:mx-0" />
              <div>
                <div className="font-semibold text-sm">Premium Quality</div>
                <div className="text-xs text-spa-300">
                  Hand-selected materials
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3 text-center md:text-left">
              <Truck className="h-8 w-8 text-bath-400 mx-auto md:mx-0" />
              <div>
                <div className="font-semibold text-sm">Free UK Delivery</div>
                <div className="text-xs text-spa-300">Orders over £25</div>
              </div>
            </div>
            <div className="flex items-center space-x-3 text-center md:text-left">
              <RotateCcw className="h-8 w-8 text-bath-400 mx-auto md:mx-0" />
              <div>
                <div className="font-semibold text-sm">30-Day Returns</div>
                <div className="text-xs text-spa-300">
                  Hassle-free guarantee
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3 text-center md:text-left">
              <Shield className="h-8 w-8 text-bath-400 mx-auto md:mx-0" />
              <div>
                <div className="font-semibold text-sm">Secure Payments</div>
                <div className="text-xs text-spa-300">Protected checkout</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main footer content */}
      <div className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Company info */}
            <div className="lg:col-span-2">
              <Link to="/" className="flex items-center space-x-2 mb-4">
                <div className="bg-bath-500 text-white p-2 rounded-lg">
                  <svg
                    className="h-6 w-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"
                    />
                  </svg>
                </div>
                <span className="text-xl font-bold font-display">
                  {SITE_CONFIG.name}
                </span>
              </Link>
              <p className="text-spa-200 mb-4 max-w-sm">
                Premium bathroom mats for UK homes. We combine comfort, style,
                and safety to transform your bathroom experience. Quality you
                can trust, delivered to your door.
              </p>

              {/* Contact info */}
              <div className="space-y-2 mb-6">
                <div className="flex items-center space-x-2 text-sm">
                  <Mail className="h-4 w-4 text-bath-400" />
                  <a
                    href={`mailto:${CONTACT_INFO.email}`}
                    className="hover:text-bath-400 transition-colors"
                  >
                    {CONTACT_INFO.email}
                  </a>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Phone className="h-4 w-4 text-bath-400" />
                  <a
                    href={`tel:${CONTACT_INFO.phone}`}
                    className="hover:text-bath-400 transition-colors"
                  >
                    {CONTACT_INFO.phone}
                  </a>
                </div>
                <div className="flex items-start space-x-2 text-sm">
                  <MapPin className="h-4 w-4 text-bath-400 mt-0.5" />
                  <div>
                    <div>
                      {CONTACT_INFO.address.line1}, {CONTACT_INFO.address.line2}
                    </div>
                    <div>
                      {CONTACT_INFO.address.city},{" "}
                      {CONTACT_INFO.address.postcode}
                    </div>
                    <div>{CONTACT_INFO.address.country}</div>
                  </div>
                </div>
              </div>

              {/* Social links */}
              <div>
                <h4 className="font-semibold mb-3">Follow Us</h4>
                <div className="flex space-x-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="hover:bg-bath-500/20 hover:text-bath-400"
                  >
                    <Facebook className="h-4 w-4" />
                    <span className="sr-only">Facebook</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="hover:bg-bath-500/20 hover:text-bath-400"
                  >
                    <Instagram className="h-4 w-4" />
                    <span className="sr-only">Instagram</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="hover:bg-bath-500/20 hover:text-bath-400"
                  >
                    <Twitter className="h-4 w-4" />
                    <span className="sr-only">Twitter</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="hover:bg-bath-500/20 hover:text-bath-400"
                  >
                    <Youtube className="h-4 w-4" />
                    <span className="sr-only">YouTube</span>
                  </Button>
                </div>
              </div>
            </div>

            {/* Footer links */}
            {NAVIGATION.footer.map((section) => (
              <div key={section.title}>
                <h4 className="font-semibold mb-4">{section.title}</h4>
                <ul className="space-y-2">
                  {section.links.map((link) => (
                    <li key={link.title}>
                      <Link
                        to={link.href}
                        className="text-spa-200 hover:text-bath-400 transition-colors text-sm"
                      >
                        {link.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Separator className="bg-spa-700" />

      {/* Bottom footer */}
      <div className="py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-spa-300">
              © {new Date().getFullYear()} {SITE_CONFIG.name}. All rights
              reserved.
            </div>
            <div className="flex flex-wrap items-center gap-6 text-sm">
              <Link
                to="/policies/privacy"
                className="text-spa-300 hover:text-bath-400 transition-colors"
              >
                Privacy Policy
              </Link>
              <Link
                to="/policies/terms"
                className="text-spa-300 hover:text-bath-400 transition-colors"
              >
                Terms of Service
              </Link>
              <Link
                to="/policies/cookies"
                className="text-spa-300 hover:text-bath-400 transition-colors"
              >
                Cookie Policy
              </Link>
              <div className="text-spa-400">🇬🇧 Made in the UK</div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

export const SITE_CONFIG = {
  name: "My Bathroom Mats",
  description:
    "Premium bathroom mats for UK homes. Comfort, style, and safety combined.",
  url: "https://mybathroommats.uk",
  domain: "mybathroommats.uk",
  tagline: "Transform Your Bathroom Experience",
  currency: "GBP",
  locale: "en-GB",
  timezone: "Europe/London",
} as const;

export const SOCIAL_LINKS = {
  facebook: "https://facebook.com/mybathroommats",
  instagram: "https://instagram.com/mybathroommats",
  twitter: "https://twitter.com/mybathroommats",
  pinterest: "https://pinterest.com/mybathroommats",
  youtube: "https://youtube.com/@mybathroommats",
  tiktok: "https://tiktok.com/@mybathroommats",
} as const;

export const CONTACT_INFO = {
  email: "hello@mybathroommats.uk",
  phone: "+44 20 1234 5678",
  address: {
    line1: "123 Bath Street",
    line2: "Suite 456",
    city: "London",
    postcode: "SW1A 1AA",
    country: "United Kingdom",
  },
  hours: {
    weekdays: "Monday - Friday: 9:00 AM - 6:00 PM",
    saturday: "Saturday: 10:00 AM - 4:00 PM",
    sunday: "Sunday: Closed",
  },
} as const;

export const POLICIES = {
  shipping: {
    title: "Shipping & Delivery",
    url: "/policies/shipping",
    summary: "Free UK delivery on orders over £25. Express delivery available.",
  },
  returns: {
    title: "Returns & Exchanges",
    url: "/policies/returns",
    summary: "30-day hassle-free returns. Customer satisfaction guaranteed.",
  },
  privacy: {
    title: "Privacy Policy",
    url: "/policies/privacy",
    summary: "Your privacy is important to us. See how we protect your data.",
  },
  terms: {
    title: "Terms of Service",
    url: "/policies/terms",
    summary: "Terms and conditions for using our website and services.",
  },
  warranty: {
    title: "Product Warranty",
    url: "/policies/warranty",
    summary: "All products come with a 1-year quality guarantee.",
  },
} as const;

export const NAVIGATION = {
  main: [
    {
      title: "Home",
      href: "/",
    },
    {
      title: "Products",
      href: "/products",
      children: [
        { title: "All Bath Mats", href: "/products" },
        { title: "Memory Foam", href: "/products?type=memory-foam" },
        { title: "Bamboo & Eco", href: "/products?type=eco-friendly" },
        { title: "Quick-Dry", href: "/products?type=quick-dry" },
        { title: "Luxury Collection", href: "/products?collection=luxury" },
      ],
    },
    {
      title: "Collections",
      href: "/collections",
    },
    {
      title: "About",
      href: "/about",
    },
    {
      title: "Contact",
      href: "/contact",
    },
  ],
  footer: [
    {
      title: "Products",
      links: [
        { title: "All Bath Mats", href: "/products" },
        { title: "Memory Foam Mats", href: "/products?type=memory-foam" },
        { title: "Bamboo Mats", href: "/products?type=bamboo" },
        { title: "Quick-Dry Mats", href: "/products?type=quick-dry" },
        { title: "Bath Mat Sets", href: "/products?type=sets" },
      ],
    },
    {
      title: "Support",
      links: [
        { title: "Contact Us", href: "/contact" },
        { title: "Size Guide", href: "/size-guide" },
        { title: "Care Instructions", href: "/care-guide" },
        { title: "FAQ", href: "/faq" },
        { title: "Live Chat", href: "#" },
      ],
    },
    {
      title: "Policies",
      links: [
        { title: "Shipping & Delivery", href: "/policies/shipping" },
        { title: "Returns & Exchanges", href: "/policies/returns" },
        { title: "Privacy Policy", href: "/policies/privacy" },
        { title: "Terms of Service", href: "/policies/terms" },
        { title: "Product Warranty", href: "/policies/warranty" },
      ],
    },
    {
      title: "Company",
      links: [
        { title: "About Us", href: "/about" },
        { title: "Our Story", href: "/story" },
        { title: "Sustainability", href: "/sustainability" },
        { title: "Reviews", href: "/reviews" },
        { title: "Blog", href: "/blog" },
      ],
    },
  ],
} as const;

export const FEATURES = [
  {
    title: "Premium Quality",
    description: "Hand-selected materials for lasting comfort and durability",
    icon: "✨",
  },
  {
    title: "UK-Made Excellence",
    description: "Proudly designed and crafted in the United Kingdom",
    icon: "🇬🇧",
  },
  {
    title: "Fast & Free Delivery",
    description: "Free UK delivery on orders over £25, next-day available",
    icon: "🚚",
  },
  {
    title: "30-Day Returns",
    description: "Not happy? Return within 30 days for a full refund",
    icon: "↩️",
  },
  {
    title: "Safety First",
    description: "Non-slip bases and safety-tested for peace of mind",
    icon: "🛡️",
  },
  {
    title: "Easy Care",
    description: "Machine washable and designed for everyday use",
    icon: "🧽",
  },
] as const;

export const TESTIMONIALS = [
  {
    name: "Sarah Johnson",
    location: "Manchester",
    rating: 5,
    comment:
      "Absolutely love my new memory foam bath mat! It's so comfortable and the non-slip base gives me confidence stepping out of the shower.",
  },
  {
    name: "David Thompson",
    location: "Edinburgh",
    rating: 5,
    comment:
      "The bamboo mat set is beautiful and feels great underfoot. Plus I love that it's eco-friendly. Fast delivery too!",
  },
  {
    name: "Emma Wilson",
    location: "Birmingham",
    rating: 5,
    comment:
      "Great quality for the price. The quick-dry feature is perfect for our busy family bathroom. Highly recommended!",
  },
] as const;

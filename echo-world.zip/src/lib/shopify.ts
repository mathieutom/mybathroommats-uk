import type {
  Product,
  ShopifyStore,
  Collection,
  FilterOptions,
} from "@/types/product";

// Mock data for demonstration - in a real app, this would connect to Shopify's Storefront API
export const mockBathroomMatsStore: ShopifyStore = {
  name: "My Bathroom Mats",
  description:
    "Premium bathroom mats for UK homes. Comfort, style, and safety combined.",
  url: "https://mybathroommats.uk",
  currency: "GBP",
  moneyFormat: "£{{amount}}",
  products: [
    {
      id: "1",
      title: "Luxury Memory Foam Bath Mat - Navy Blue",
      description:
        "Ultra-soft memory foam bath mat with superior water absorption. Non-slip base ensures safety. Machine washable and quick-dry technology.",
      price: 24.99,
      compareAtPrice: 34.99,
      handle: "luxury-memory-foam-bath-mat-navy",
      vendor: "My Bathroom Mats",
      productType: "Bath Mat",
      tags: ["memory foam", "luxury", "non-slip", "quick-dry", "navy"],
      available: true,
      createdAt: "2024-01-15T10:00:00Z",
      updatedAt: "2024-01-20T10:00:00Z",
      images: [
        {
          id: "img1",
          url: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&h=600&fit=crop",
          altText: "Navy blue memory foam bath mat",
          width: 800,
          height: 600,
        },
        {
          id: "img2",
          url: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop",
          altText: "Bath mat in bathroom setting",
          width: 800,
          height: 600,
        },
      ],
      variants: [
        {
          id: "var1",
          title: "Small / Navy Blue",
          price: 24.99,
          compareAtPrice: 34.99,
          available: true,
          inventory: 25,
          selectedOptions: [
            { name: "Size", value: "Small" },
            { name: "Color", value: "Navy Blue" },
          ],
        },
        {
          id: "var2",
          title: "Large / Navy Blue",
          price: 34.99,
          compareAtPrice: 44.99,
          available: true,
          inventory: 15,
          selectedOptions: [
            { name: "Size", value: "Large" },
            { name: "Color", value: "Navy Blue" },
          ],
        },
      ],
      options: [
        {
          id: "opt1",
          name: "Size",
          values: ["Small", "Large"],
        },
        {
          id: "opt2",
          name: "Color",
          values: ["Navy Blue", "Charcoal Grey", "Cream White"],
        },
      ],
      featuredImage: {
        id: "img1",
        url: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&h=600&fit=crop",
        altText: "Navy blue memory foam bath mat",
        width: 800,
        height: 600,
      },
    },
    {
      id: "2",
      title: "Bamboo Bath Mat Set - Natural",
      description:
        "Eco-friendly bamboo bath mat set. Naturally antimicrobial and water-resistant. Includes 2 mats for complete bathroom coverage.",
      price: 39.99,
      compareAtPrice: 54.99,
      handle: "bamboo-bath-mat-set-natural",
      vendor: "My Bathroom Mats",
      productType: "Bath Mat Set",
      tags: ["bamboo", "eco-friendly", "natural", "antimicrobial", "set"],
      available: true,
      createdAt: "2024-01-10T10:00:00Z",
      updatedAt: "2024-01-18T10:00:00Z",
      images: [
        {
          id: "img3",
          url: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop",
          altText: "Natural bamboo bath mat",
          width: 800,
          height: 600,
        },
      ],
      variants: [
        {
          id: "var3",
          title: "Standard / Natural",
          price: 39.99,
          compareAtPrice: 54.99,
          available: true,
          inventory: 20,
          selectedOptions: [
            { name: "Size", value: "Standard" },
            { name: "Finish", value: "Natural" },
          ],
        },
      ],
      options: [
        {
          id: "opt3",
          name: "Size",
          values: ["Standard"],
        },
        {
          id: "opt4",
          name: "Finish",
          values: ["Natural", "Dark Walnut"],
        },
      ],
      featuredImage: {
        id: "img3",
        url: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop",
        altText: "Natural bamboo bath mat",
        width: 800,
        height: 600,
      },
    },
    {
      id: "3",
      title: "Microfiber Quick-Dry Mat - Grey",
      description:
        "Super absorbent microfiber bath mat that dries in minutes. Perfect for busy households. Machine washable and fade-resistant.",
      price: 16.99,
      compareAtPrice: 24.99,
      handle: "microfiber-quick-dry-mat-grey",
      vendor: "My Bathroom Mats",
      productType: "Bath Mat",
      tags: ["microfiber", "quick-dry", "absorbent", "grey", "budget"],
      available: true,
      createdAt: "2024-01-12T10:00:00Z",
      updatedAt: "2024-01-19T10:00:00Z",
      images: [
        {
          id: "img4",
          url: "https://images.unsplash.com/photo-1503602642458-232111445657?w=800&h=600&fit=crop",
          altText: "Grey microfiber bath mat",
          width: 800,
          height: 600,
        },
      ],
      variants: [
        {
          id: "var4",
          title: "Medium / Grey",
          price: 16.99,
          compareAtPrice: 24.99,
          available: true,
          inventory: 30,
          selectedOptions: [
            { name: "Size", value: "Medium" },
            { name: "Color", value: "Grey" },
          ],
        },
      ],
      options: [
        {
          id: "opt5",
          name: "Size",
          values: ["Medium", "Large"],
        },
        {
          id: "opt6",
          name: "Color",
          values: ["Grey", "White", "Beige"],
        },
      ],
      featuredImage: {
        id: "img4",
        url: "https://images.unsplash.com/photo-1503602642458-232111445657?w=800&h=600&fit=crop",
        altText: "Grey microfiber bath mat",
        width: 800,
        height: 600,
      },
    },
  ],
  collections: [
    {
      id: "col1",
      title: "Luxury Collection",
      description: "Premium bath mats for the discerning homeowner",
      handle: "luxury-collection",
      products: [],
    },
    {
      id: "col2",
      title: "Eco-Friendly",
      description: "Sustainable and environmentally conscious bath mats",
      handle: "eco-friendly",
      products: [],
    },
  ],
};

export async function fetchProductsFromShopify(
  storeUrl?: string,
): Promise<Product[]> {
  // In a real application, this would use the Shopify Storefront API
  // For now, return mock data
  await new Promise((resolve) => setTimeout(resolve, 500)); // Simulate API delay
  return mockBathroomMatsStore.products;
}

export async function fetchProductByHandle(
  handle: string,
): Promise<Product | null> {
  await new Promise((resolve) => setTimeout(resolve, 300));
  return (
    mockBathroomMatsStore.products.find(
      (product) => product.handle === handle,
    ) || null
  );
}

export async function fetchCollections(): Promise<Collection[]> {
  await new Promise((resolve) => setTimeout(resolve, 300));
  return mockBathroomMatsStore.collections;
}

export function filterProducts(
  products: Product[],
  filters: FilterOptions,
): Product[] {
  let filteredProducts = [...products];

  if (filters.priceRange) {
    const [min, max] = filters.priceRange;
    filteredProducts = filteredProducts.filter(
      (product) => product.price >= min && product.price <= max,
    );
  }

  if (filters.productTypes && filters.productTypes.length > 0) {
    filteredProducts = filteredProducts.filter((product) =>
      filters.productTypes!.includes(product.productType),
    );
  }

  if (filters.tags && filters.tags.length > 0) {
    filteredProducts = filteredProducts.filter((product) =>
      filters.tags!.some((tag) => product.tags.includes(tag)),
    );
  }

  if (filters.sortBy) {
    filteredProducts.sort((a, b) => {
      switch (filters.sortBy) {
        case "price-asc":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "title-asc":
          return a.title.localeCompare(b.title);
        case "title-desc":
          return b.title.localeCompare(a.title);
        case "created-desc":
          return (
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
        case "created-asc":
          return (
            new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
          );
        default:
          return 0;
      }
    });
  }

  return filteredProducts;
}

export function formatPrice(price: number, currency: string = "GBP"): string {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: currency,
  }).format(price);
}

import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  Heart,
  ShoppingCart,
  Star,
  Truck,
  RotateCcw,
  Shield,
  Share,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Separator } from "@/components/ui/separator";
import ProductCard from "@/components/ProductCard";
import Layout from "@/components/Layout";
import {
  fetchProductByHandle,
  fetchProductsFromShopify,
  formatPrice,
} from "@/lib/shopify";
import type { Product, ProductVariant } from "@/types/product";

const ProductDetail = () => {
  const { handle } = useParams<{ handle: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(
    null,
  );
  const [selectedOptions, setSelectedOptions] = useState<
    Record<string, string>
  >({});
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [imageIndex, setImageIndex] = useState(0);

  useEffect(() => {
    const loadProduct = async () => {
      if (!handle) return;

      try {
        const productData = await fetchProductByHandle(handle);
        setProduct(productData);

        if (productData) {
          // Set default variant
          setSelectedVariant(productData.variants[0]);

          // Set default options
          const defaultOptions: Record<string, string> = {};
          productData.options.forEach((option) => {
            defaultOptions[option.name] = option.values[0];
          });
          setSelectedOptions(defaultOptions);

          // Load related products
          const allProducts = await fetchProductsFromShopify();
          const related = allProducts
            .filter(
              (p) =>
                p.id !== productData.id &&
                p.productType === productData.productType,
            )
            .slice(0, 4);
          setRelatedProducts(related);
        }
      } catch (error) {
        console.error("Error loading product:", error);
      } finally {
        setLoading(false);
      }
    };

    loadProduct();
  }, [handle]);

  useEffect(() => {
    if (!product) return;

    // Find matching variant based on selected options
    const matchingVariant = product.variants.find((variant) =>
      variant.selectedOptions.every(
        (option) => selectedOptions[option.name] === option.value,
      ),
    );

    if (matchingVariant) {
      setSelectedVariant(matchingVariant);
    }
  }, [selectedOptions, product]);

  const handleOptionChange = (optionName: string, value: string) => {
    setSelectedOptions((prev) => ({
      ...prev,
      [optionName]: value,
    }));
  };

  const discountPercentage =
    product?.compareAtPrice && selectedVariant?.compareAtPrice
      ? Math.round(
          ((selectedVariant.compareAtPrice - selectedVariant.price) /
            selectedVariant.compareAtPrice) *
            100,
        )
      : 0;

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="aspect-square bg-gray-200 rounded-lg"></div>
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-6 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!product) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <p className="text-muted-foreground mb-6">
            The product you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link to="/products">Browse All Products</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/">Home</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/products">Products</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>{product.title}</BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        {/* Product Details */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
              <img
                src={
                  product.images[imageIndex]?.url || product.featuredImage?.url
                }
                alt={product.images[imageIndex]?.altText || product.title}
                className="w-full h-full object-cover"
              />
            </div>

            {product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((image, index) => (
                  <button
                    key={image.id}
                    onClick={() => setImageIndex(index)}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-colors ${
                      index === imageIndex
                        ? "border-bath-500"
                        : "border-gray-200"
                    }`}
                  >
                    <img
                      src={image.url}
                      alt={image.altText}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Title and Rating */}
            <div>
              <h1 className="text-3xl md:text-4xl font-bold font-display mb-4">
                {product.title}
              </h1>
              <div className="flex items-center space-x-4 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < 4 ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  (127 reviews)
                </span>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-center space-x-4">
              <span className="text-3xl font-bold text-bath-600">
                {formatPrice(selectedVariant?.price || product.price)}
              </span>
              {selectedVariant?.compareAtPrice && (
                <>
                  <span className="text-xl text-muted-foreground line-through">
                    {formatPrice(selectedVariant.compareAtPrice)}
                  </span>
                  <Badge className="bg-red-500 text-white">
                    Save {discountPercentage}%
                  </Badge>
                </>
              )}
            </div>

            {/* Description */}
            <p className="text-lg text-muted-foreground">
              {product.description}
            </p>

            {/* Product Options */}
            <div className="space-y-4">
              {product.options.map((option) => (
                <div key={option.id}>
                  <label className="text-sm font-medium mb-2 block">
                    {option.name}
                  </label>
                  <Select
                    value={selectedOptions[option.name]}
                    onValueChange={(value) =>
                      handleOptionChange(option.name, value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {option.values.map((value) => (
                        <SelectItem key={value} value={value}>
                          {value}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>

            {/* Quantity */}
            <div>
              <label className="text-sm font-medium mb-2 block">Quantity</label>
              <Select
                value={quantity.toString()}
                onValueChange={(value) => setQuantity(Number(value))}
              >
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[...Array(10)].map((_, i) => (
                    <SelectItem key={i + 1} value={(i + 1).toString()}>
                      {i + 1}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Add to Cart */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="btn-primary flex-1"
                disabled={!selectedVariant?.available}
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                {selectedVariant?.available ? "Add to Cart" : "Out of Stock"}
              </Button>
              <Button variant="outline" size="lg" className="btn-secondary">
                <Heart className="h-4 w-4 mr-2" />
                Wishlist
              </Button>
              <Button variant="outline" size="lg">
                <Share className="h-4 w-4" />
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t">
              <div className="text-center">
                <Truck className="h-6 w-6 text-bath-500 mx-auto mb-2" />
                <div className="text-sm font-medium">Free Delivery</div>
                <div className="text-xs text-muted-foreground">
                  Orders over £25
                </div>
              </div>
              <div className="text-center">
                <RotateCcw className="h-6 w-6 text-bath-500 mx-auto mb-2" />
                <div className="text-sm font-medium">30-Day Returns</div>
                <div className="text-xs text-muted-foreground">Hassle-free</div>
              </div>
              <div className="text-center">
                <Shield className="h-6 w-6 text-bath-500 mx-auto mb-2" />
                <div className="text-sm font-medium">Quality Guarantee</div>
                <div className="text-xs text-muted-foreground">
                  1-year warranty
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mb-16">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="care">Care Instructions</TabsTrigger>
              <TabsTrigger value="reviews">Reviews (127)</TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="prose max-w-none">
                    <p>{product.description}</p>
                    <ul className="mt-4">
                      <li>
                        Premium memory foam construction for ultimate comfort
                      </li>
                      <li>Non-slip rubber backing for safety</li>
                      <li>Quick-dry technology prevents mold and mildew</li>
                      <li>Machine washable for easy maintenance</li>
                      <li>Available in multiple sizes and colors</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="specifications" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold mb-2">Dimensions</h4>
                      <ul className="text-sm space-y-1">
                        <li>Small: 40cm x 60cm</li>
                        <li>Large: 50cm x 80cm</li>
                        <li>Thickness: 2.5cm</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Materials</h4>
                      <ul className="text-sm space-y-1">
                        <li>Top: Memory foam with microfiber cover</li>
                        <li>Bottom: Non-slip rubber</li>
                        <li>Weight: 0.8kg - 1.2kg</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="care" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">
                        Washing Instructions
                      </h4>
                      <ul className="text-sm space-y-1">
                        <li>• Machine wash on gentle cycle (30°C)</li>
                        <li>• Use mild detergent, no bleach</li>
                        <li>• Air dry or tumble dry on low heat</li>
                        <li>• Do not iron or dry clean</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Daily Care</h4>
                      <ul className="text-sm space-y-1">
                        <li>• Shake out excess water after use</li>
                        <li>• Hang to air dry when possible</li>
                        <li>• Vacuum regularly to remove debris</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center text-muted-foreground">
                    Customer reviews coming soon...
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl md:text-3xl font-bold font-display">
                You Might Also Like
              </h2>
              <Button asChild variant="outline">
                <Link to="/products">View All</Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ProductDetail;

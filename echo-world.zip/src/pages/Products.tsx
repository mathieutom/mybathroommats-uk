import { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Filter, Grid, List, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import ProductCard from "@/components/ProductCard";
import Layout from "@/components/Layout";
import { fetchProductsFromShopify, filterProducts } from "@/lib/shopify";
import type { Product, FilterOptions } from "@/types/product";

const Products = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [filters, setFilters] = useState<FilterOptions>({
    priceRange: [0, 100],
    sortBy: "created-desc",
    productTypes: [],
    tags: [],
  });

  // Extract filter values from URL params
  useEffect(() => {
    const type = searchParams.get("type");
    const collection = searchParams.get("collection");
    const sort = searchParams.get("sort");

    const newFilters: FilterOptions = {
      ...filters,
      sortBy: (sort as FilterOptions["sortBy"]) || "created-desc",
    };

    if (type) {
      newFilters.tags = [type];
    }

    if (collection) {
      newFilters.collections = [collection];
    }

    setFilters(newFilters);
  }, [searchParams]);

  useEffect(() => {
    const loadProducts = async () => {
      try {
        const allProducts = await fetchProductsFromShopify();
        setProducts(allProducts);
      } catch (error) {
        console.error("Error loading products:", error);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  useEffect(() => {
    if (products.length > 0) {
      const filtered = filterProducts(products, filters);
      setFilteredProducts(filtered);
    }
  }, [products, filters]);

  const updateFilters = (newFilters: Partial<FilterOptions>) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  const updateURLParams = (key: string, value: string | null) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setSearchParams(newParams);
  };

  const availableTypes = [...new Set(products.map((p) => p.productType))];
  const availableTags = [...new Set(products.flatMap((p) => p.tags))];
  const priceRange =
    products.length > 0
      ? [
          Math.min(...products.map((p) => p.price)),
          Math.max(...products.map((p) => p.price)),
        ]
      : [0, 100];

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Price Range */}
      <div>
        <h3 className="font-semibold mb-3">Price Range</h3>
        <div className="px-2">
          <Slider
            value={filters.priceRange || [0, 100]}
            onValueChange={(value) =>
              updateFilters({ priceRange: value as [number, number] })
            }
            max={priceRange[1]}
            min={priceRange[0]}
            step={1}
            className="mb-2"
          />
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>£{filters.priceRange?.[0] || 0}</span>
            <span>£{filters.priceRange?.[1] || 100}</span>
          </div>
        </div>
      </div>

      {/* Product Types */}
      <div>
        <h3 className="font-semibold mb-3">Product Type</h3>
        <div className="space-y-2">
          {availableTypes.map((type) => (
            <div key={type} className="flex items-center space-x-2">
              <Checkbox
                id={`type-${type}`}
                checked={filters.productTypes?.includes(type)}
                onCheckedChange={(checked) => {
                  const newTypes = checked
                    ? [...(filters.productTypes || []), type]
                    : (filters.productTypes || []).filter((t) => t !== type);
                  updateFilters({ productTypes: newTypes });
                }}
              />
              <label htmlFor={`type-${type}`} className="text-sm">
                {type}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Tags */}
      <div>
        <h3 className="font-semibold mb-3">Features</h3>
        <div className="space-y-2">
          {availableTags.slice(0, 8).map((tag) => (
            <div key={tag} className="flex items-center space-x-2">
              <Checkbox
                id={`tag-${tag}`}
                checked={filters.tags?.includes(tag)}
                onCheckedChange={(checked) => {
                  const newTags = checked
                    ? [...(filters.tags || []), tag]
                    : (filters.tags || []).filter((t) => t !== tag);
                  updateFilters({ tags: newTags });
                }}
              />
              <label htmlFor={`tag-${tag}`} className="text-sm capitalize">
                {tag}
              </label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const getPageTitle = () => {
    const type = searchParams.get("type");
    const collection = searchParams.get("collection");

    if (type) {
      return (
        type
          .split("-")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ") + " Bath Mats"
      );
    }

    if (collection) {
      return (
        collection
          .split("-")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ") + " Collection"
      );
    }

    return "All Bath Mats";
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/">Home</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/products">Products</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            {searchParams.get("type") && (
              <>
                <BreadcrumbSeparator />
                <BreadcrumbItem>{getPageTitle()}</BreadcrumbItem>
              </>
            )}
          </BreadcrumbList>
        </Breadcrumb>

        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold font-display mb-4">
            {getPageTitle()}
          </h1>
          <p className="text-lg text-muted-foreground">
            Discover our range of premium bathroom mats designed for comfort,
            safety, and style.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Desktop Filters */}
          <div className="hidden lg:block">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold mb-4 flex items-center">
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                </h2>
                <FilterContent />
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <div className="flex items-center gap-4">
                {/* Mobile Filters */}
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="lg:hidden">
                      <SlidersHorizontal className="h-4 w-4 mr-2" />
                      Filters
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[300px]">
                    <SheetHeader>
                      <SheetTitle>Filters</SheetTitle>
                    </SheetHeader>
                    <div className="mt-6">
                      <FilterContent />
                    </div>
                  </SheetContent>
                </Sheet>

                {/* Results count */}
                <div className="text-sm text-muted-foreground">
                  {loading
                    ? "Loading..."
                    : `${filteredProducts.length} products`}
                </div>
              </div>

              <div className="flex items-center gap-4">
                {/* Sort */}
                <Select
                  value={filters.sortBy}
                  onValueChange={(value) => {
                    updateFilters({ sortBy: value as FilterOptions["sortBy"] });
                    updateURLParams("sort", value);
                  }}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="created-desc">Newest First</SelectItem>
                    <SelectItem value="created-asc">Oldest First</SelectItem>
                    <SelectItem value="price-asc">
                      Price: Low to High
                    </SelectItem>
                    <SelectItem value="price-desc">
                      Price: High to Low
                    </SelectItem>
                    <SelectItem value="title-asc">Name: A to Z</SelectItem>
                    <SelectItem value="title-desc">Name: Z to A</SelectItem>
                  </SelectContent>
                </Select>

                {/* View Mode */}
                <div className="flex items-center border rounded-lg">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className="rounded-r-none"
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="rounded-l-none"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Active Filters */}
            {(filters.productTypes?.length || filters.tags?.length) && (
              <div className="flex flex-wrap gap-2 mb-6">
                {filters.productTypes?.map((type) => (
                  <Badge
                    key={type}
                    variant="secondary"
                    className="cursor-pointer"
                    onClick={() => {
                      const newTypes = filters.productTypes?.filter(
                        (t) => t !== type,
                      );
                      updateFilters({ productTypes: newTypes });
                    }}
                  >
                    {type} ×
                  </Badge>
                ))}
                {filters.tags?.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="cursor-pointer"
                    onClick={() => {
                      const newTags = filters.tags?.filter((t) => t !== tag);
                      updateFilters({ tags: newTags });
                    }}
                  >
                    {tag} ×
                  </Badge>
                ))}
              </div>
            )}

            {/* Products Grid */}
            {loading ? (
              <div
                className={`grid gap-6 ${
                  viewMode === "grid"
                    ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-3"
                    : "grid-cols-1"
                }`}
              >
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-200 aspect-square rounded-lg mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-muted-foreground mb-4">
                  No products found matching your criteria.
                </div>
                <Button
                  variant="outline"
                  onClick={() => {
                    setFilters({
                      priceRange: [0, 100],
                      sortBy: "created-desc",
                    });
                    setSearchParams({});
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div
                className={`grid gap-6 ${
                  viewMode === "grid"
                    ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-3"
                    : "grid-cols-1"
                }`}
              >
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    className={viewMode === "list" ? "flex-row" : ""}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Products;

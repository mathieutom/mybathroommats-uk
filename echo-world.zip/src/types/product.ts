export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  compareAtPrice?: number;
  images: ProductImage[];
  variants: ProductVariant[];
  handle: string;
  vendor: string;
  productType: string;
  tags: string[];
  available: boolean;
  createdAt: string;
  updatedAt: string;
  featuredImage?: ProductImage;
  options: ProductOption[];
  metafields?: Metafield[];
}

export interface ProductImage {
  id: string;
  url: string;
  altText?: string;
  width: number;
  height: number;
}

export interface ProductVariant {
  id: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  sku?: string;
  available: boolean;
  inventory: number;
  selectedOptions: SelectedOption[];
  image?: ProductImage;
  weight?: number;
  weightUnit?: string;
}

export interface ProductOption {
  id: string;
  name: string;
  values: string[];
}

export interface SelectedOption {
  name: string;
  value: string;
}

export interface Metafield {
  id: string;
  key: string;
  value: string;
  type: string;
  namespace: string;
}

export interface Collection {
  id: string;
  title: string;
  description: string;
  handle: string;
  image?: ProductImage;
  products: Product[];
}

export interface CartItem {
  id: string;
  product: Product;
  variant: ProductVariant;
  quantity: number;
}

export interface Cart {
  id: string;
  items: CartItem[];
  totalPrice: number;
  totalQuantity: number;
  estimatedCost: {
    totalAmount: number;
    subtotalAmount: number;
    totalTaxAmount: number;
    totalDutyAmount?: number;
  };
}

export interface ShopifyStore {
  name: string;
  description: string;
  url: string;
  currency: string;
  moneyFormat: string;
  products: Product[];
  collections: Collection[];
}

export interface FilterOptions {
  priceRange?: [number, number];
  collections?: string[];
  productTypes?: string[];
  vendors?: string[];
  tags?: string[];
  sortBy?:
    | "price-asc"
    | "price-desc"
    | "title-asc"
    | "title-desc"
    | "created-asc"
    | "created-desc"
    | "best-selling";
}
